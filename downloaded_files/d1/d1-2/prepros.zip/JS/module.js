import Info from "./info.js";

let info = new Info();
info.info(info.users);

// import { info, users } from 'D:/Скачал/VSCode/JS and HTMLS/JS/info.js';

// info();