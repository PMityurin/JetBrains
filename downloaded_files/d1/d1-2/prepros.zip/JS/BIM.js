// console.log(window.innerHeight);

// window.open('about:blank', 'hello', 'width=200,height=200');

// console.log(navigator.platform); 
//platform , userAgent , 

// console.log(location.href);
// setTimeout(function(){
//     location.reload();
// }, 2000);

// location.href = 'https://itproger.com';